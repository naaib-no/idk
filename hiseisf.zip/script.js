function showSection(id) {
  document.querySelectorAll('section').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  
  if (id === "razones" && !document.querySelector(".tarjeta")) {
    generarTarjetas();
  }
}

function jugar() {
  const mensajes = [
    "Eres mi lugar seguro 🤍",
    "Cada día contigo es especial ✨",
    "Gracias por existir, mi amor 🕊️"
  ];
  const random = Math.floor(Math.random() * mensajes.length);
  document.getElementById('resultadoJuego').textContent = mensajes[random];
}

const mensajesCorazon = [
  "Eres mi omekita cawai",
  "Eres mi alma gemela",
  "Iluminas mis dias mas oscuros con tu presencia",
  "Gracias por quedarte a mi lado a pesar de todo",
  "Eres mi niño de ojitos preciosos",
  "Siempre voy a cuidarte y amarte ",
  "Tu amor hace que mi corazon se derrita por completo como helado al sol",
  "Cada latido mío dice tu nombre ",
  "Solamente tengo ojos para ti",
  "Te amo muchisissisisisissisimo de aqui a la luna mi amado chico",
  "Eres mi razón de sonreír cada día",
];

function crearCorazon() {
  const contenedor = document.getElementById("heart-game-container");
  const corazon = document.createElement("div");
  corazon.innerHTML = "💗";
  corazon.style.position = "absolute";
  corazon.style.fontSize = "24px";
  corazon.style.left = Math.random() * 90 + "%";
  corazon.style.top = "-30px";
  corazon.style.cursor = "pointer";
  corazon.style.userSelect = "none";
  corazon.style.transition = "top 5s linear";

  corazon.onclick = () => {
    const mensaje = mensajesCorazon[Math.floor(Math.random() * mensajesCorazon.length)];
    document.getElementById("mensajeCorazon").textContent = mensaje;
    contenedor.removeChild(corazon);
  };

  contenedor.appendChild(corazon);

  setTimeout(() => {
    corazon.style.top = "400px";
  }, 10);

  setTimeout(() => {
    if (contenedor.contains(corazon)) contenedor.removeChild(corazon);
  }, 5500);
}

setInterval(crearCorazon, 1500);

function toggleMusic() {
  const music = document.getElementById('bgMusic');
  if (music.paused) {
    music.play();
  } else {
    music.pause();
  }
}

function openModal() {
  document.getElementById('modalConfirm').style.display = 'flex';
}

function enterSite() {
  document.getElementById('welcomeScreen')?.style.display = 'none';
  document.getElementById('modalConfirm').style.display = 'none';
  document.getElementById('navbar').style.display = 'block';
  document.querySelector('#inicio').classList.add('active');
  document.getElementById('bgMusic').play();
}

function stayHere() {
  const modalBox = document.getElementById('modalBox');
  modalBox.innerHTML = `
    <p style="color:#47637a;">¿Por qué no quieres ver la página que te hice con tanto amor mi lindo esposito?😭</p>
    <button onclick="enterSite()">Está bien, sí quiero verla</button>
    <button onclick="closeModal()">Otra oportunidad</button>
  `;
}

function closeModal() {
  document.getElementById('modalConfirm').style.display = 'none';
}

// Cuenta regresiva
const birthday = new Date("2025-07-12T00:00:00").getTime();
const countdownElement = document.getElementById('countdown');
setInterval(() => {
  const now = new Date().getTime();
  const distance = birthday - now;
  const days = Math.floor(distance / (1000 * 60 * 60 * 24));
  const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((distance % (1000 * 60)) / 1000);
  countdownElement.innerHTML = `Faltan <strong>${days}</strong> días, <strong>${hours}</strong> horas, <strong>${minutes}</strong> minutos y <strong>${seconds}</strong> segundos para tu cumpleaños mi amado chico ♡ .`;
}, 1000);

const razones = [
  "Eres mi luz que ilumina mis días más oscuros",
  "Llenas de colores mi vida",
  // ... el resto de las razones (200 en total) ...
  "La verdad te amo por todo lo que eres como persona incluyendo tus defectos, sé que somos humanos y obvio que tenemos defectos pero también amo esa parte de ti, te amo como la persona que eres, incluso si me muestras tus espinas solo quiero demostrarte que no eres dificil de amar y que me quedare a tu lado sin importar que, porque eres la persona mas importante en mi vida y no me imagino un futuro sin ti",
];

function generarTarjetas() {
  const contenedor = document.getElementById("contenedor-razones");
  razones.forEach((texto, index) => {
    const tarjeta = document.createElement("div");
    tarjeta.className = "tarjeta";
    tarjeta.style.animationDelay = `${index * 0.05}s`;
    tarjeta.textContent = texto;
    contenedor.appendChild(tarjeta);
  });
}
